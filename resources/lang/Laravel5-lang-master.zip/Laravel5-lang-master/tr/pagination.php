<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Sayfalama metinleri
    |--------------------------------------------------------------------------
    |
    | Aşağıdaki metinler sayfalama kütüphanelerinin linklerini oluşturmak
    | için kullandıkları mesajlardır. Bu metinleri uygulamanızın
    | tasarım ihtiyaçlarına göre değiştirmekte özgürsünüz.
    |
    */

    'previous' => '&laquo; Önceki',
    'next' => 'Sonraki &raquo;',
];
